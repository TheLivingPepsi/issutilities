import colors, directories, actions, craft

COLORS = colors.ANSI
DIRS = directories
ACTIONS = actions.CONSOLE
CRAFT = craft.DISCORD