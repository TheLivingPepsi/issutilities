import colors, directories, actions, craft

COLORS = colors
DIRS = directories
ACTIONS = actions
CRAFT = craft.DISCORD