# issutilities

Utilities package for issu's discord bots.

## Installation

Run `py -3 -m pip install -U issutilities` (Windows) or `python3 -m pip install -U issutilities` (MacOS/Linux)

Das it
